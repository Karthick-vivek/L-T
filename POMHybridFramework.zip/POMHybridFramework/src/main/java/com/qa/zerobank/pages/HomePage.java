package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class HomePage extends TestBase {
	
	// object repository
	@FindBy(id="signin_button")
	WebElement signInButton;	
	@FindBy(name="searchTerm")
	WebElement searchBox;		
	@FindBy(linkText = "Zero Bank")
	WebElement brandLinkZeroBank;	
	@FindBy(css = "#online-banking")
	WebElement buttonMoreServices;	
	@FindBy(className = "brand")
	WebElement brandLogo;
	
	
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	
	public void assertHomePageTitle(){
		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Home page title assert Failed");
		
	}
	
	
	public boolean validateBandLogo() {
		return brandLogo.isDisplayed();
	}

	
	public LogInPage clickOnSignInButton() {
		signInButton.click();
		return new LogInPage();		
	}

}
