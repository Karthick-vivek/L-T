package com.qa.zerobank.testcases;

import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class LogInPageTestcases extends TestBase {
	
	HomePage homePage;
	LogInPage logInPage;
	AccountSummaryPage accountSummaryPage;
	
	public LogInPageTestcases() {
		super();
	}
	
  @BeforeMethod
  public void beforeMethod() {
	  	initialization();
		homePage = new HomePage();
		logInPage = new LogInPage();
		accountSummaryPage = new AccountSummaryPage();
  }

  @AfterMethod
  public void afterMethod() {
	  	// close driver
		driver.close();
		driver.quit();
  }
  
  @Test
  public void validatLogInPage() {
	  	logInPage = homePage.clickOnSignInButton();
		logInPage.assertLogInPageTitle();
  }
  
  @Test
	public void validateLogInFunctionality() {
		logInPage = homePage.clickOnSignInButton();
		accountSummaryPage = logInPage.logIn();
		accountSummaryPage.assertAccountSummaryPageTitle();
	}
  
  

}
