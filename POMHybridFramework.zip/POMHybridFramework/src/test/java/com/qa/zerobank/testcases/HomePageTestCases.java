package com.qa.zerobank.testcases;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;

public class HomePageTestCases extends TestBase {
	
	HomePage homePage;
	LogInPage logInPage;
	
	public HomePageTestCases() {
		super();
	}
	
	@BeforeMethod
	public void setUp () {
		initialization();
		homePage = new HomePage();
		logInPage = new LogInPage();
	}
	
	@AfterMethod
	public void cleanUp () {
		// close driver
		driver.close();
		driver.quit();	
	}
	
	@Test
	public void validateHomePage() {
		homePage.assertHomePageTitle();
	}
	
	
	@Test
	public void validateLogo() {
		assertTrue(homePage.validateBandLogo());
	}
	
	@Test
	public void signInButtonTest() {
		logInPage = homePage.clickOnSignInButton();
		logInPage.assertLogInPageTitle();		
	}
	
}
